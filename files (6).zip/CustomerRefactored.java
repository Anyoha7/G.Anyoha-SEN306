/**
 * CustomerRefactored.java
 * Refactored version of the original processCustomer routine.
 * Requires: Customer.java in the same directory/project.
 */
public class CustomerRefactored {

    // ---------------------------------------------------------------
    // 1. Input validation
    // ---------------------------------------------------------------
    public static void validateCustomer(Customer c) {
        if (c.name == null || c.name.isBlank())
            throw new IllegalArgumentException("Customer name must not be empty.");
        if (c.address == null || c.address.isBlank())
            throw new IllegalArgumentException("Customer address must not be empty.");
        if (c.orderCount < 0)
            throw new IllegalArgumentException("Order count must be non-negative.");
        if (c.orders == null || c.orders.length < c.orderCount)
            throw new IllegalArgumentException("Orders array is too short for the given order count.");
        for (int i = 0; i < c.orderCount; i++) {
            if (c.orders[i] < 0)
                throw new IllegalArgumentException(
                    "Order amount at index " + i + " must be non-negative.");
        }
        if (c.customerType != 0 && c.customerType != 1 && c.customerType != 2)
            throw new IllegalArgumentException(
                "Customer type must be 0 (standard), 1 (silver), or 2 (gold).");
    }

    // ---------------------------------------------------------------
    // 2. Calculate order sum
    // ---------------------------------------------------------------
    public static double orderTotal(Customer c) {
        double sum = 0;
        for (int i = 0; i < c.orderCount; i++) {
            sum += c.orders[i];
        }
        return sum;
    }

    // ---------------------------------------------------------------
    // 3. Determine discount rate based on customer type
    // ---------------------------------------------------------------
    public static double discountRate(int customerType) {
        if (customerType == 1) return 0.10;   // silver – 10%
        if (customerType == 2) return 0.20;   // gold   – 20%
        return 0.0;                            // standard
    }

    // ---------------------------------------------------------------
    // 4. Apply discount and return the final total
    // ---------------------------------------------------------------
    public static double applyDiscount(double subtotal, double rate) {
        return subtotal - subtotal * rate;
    }

    // ---------------------------------------------------------------
    // 5. Build the greeting message
    // ---------------------------------------------------------------
    public static String buildGreeting(Customer c, double total) {
        String msg = "Hello " + c.name + " of " + c.address
                   + ", your total is " + total;
        if (c.isVip) msg += " (VIP)";
        return msg;
    }

    // ---------------------------------------------------------------
    // 6. Send notification (print + optional email)
    // ---------------------------------------------------------------
    public static void sendNotification(Customer c, String message) {
        System.out.println(message);
        if (c.email != null && !c.email.isBlank()) {
            sendEmail(c.email, message);
        }
    }

    // Stub – assumed to exist in the original codebase
    public static void sendEmail(String email, String message) {
        System.out.println("[EMAIL to " + email + "]: " + message);
    }

    // ---------------------------------------------------------------
    // 7. Top-level orchestrator (replaces the original processCustomer)
    //    Returns the computed total so the caller can update balance –
    //    fixing the silent pass-by-value bug of the original 'd = total'.
    // ---------------------------------------------------------------
    public static double processCustomer(Customer c) {
        validateCustomer(c);

        double subtotal = orderTotal(c);
        double rate     = discountRate(c.customerType);
        double total    = applyDiscount(subtotal, rate);

        String greeting = buildGreeting(c, total);
        sendNotification(c, greeting);

        return total;  // caller does: c.balance = processCustomer(c);
    }

    // ---------------------------------------------------------------
    // Demo main
    // ---------------------------------------------------------------
    public static void main(String[] args) {
        double[] orders = {150.0, 200.0, 50.0};

        Customer alice = new Customer(
            "Alice",           // name
            "Lagos",           // address
            0.0,               // balance (set after processing)
            2,                 // gold customer
            "alice@email.com", // email
            true,              // VIP
            orders,            // orders
            3                  // orderCount
        );

        // Explicit assignment – no silent pass-by-value failure
        alice.balance = processCustomer(alice);
        System.out.println("Updated balance: " + alice.balance);
    }
}
