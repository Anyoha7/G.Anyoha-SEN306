# REFLECTION.md – Refactoring `processCustomer`

---

## 1. How did you achieve functional cohesion? Which routines did you extract?

The original `processCustomer` did at least five unrelated things inside one method: summing orders, computing a discount, building a greeting string, printing output, and trying to update an external variable. Each concern was mixed together, making the routine hard to test, name, or reuse.

I extracted **six cohesive routines**, each with a single, clear responsibility:

| Routine | Responsibility |
|---|---|
| `validateCustomer(Customer c)` | Checks all inputs for legality before any work starts |
| `orderTotal(Customer c)` | Sums the orders array – pure calculation |
| `discountRate(int customerType)` | Maps a customer type to a discount percentage – pure lookup |
| `applyDiscount(double subtotal, double rate)` | Applies the rate – pure arithmetic |
| `buildGreeting(Customer c, double total)` | Constructs the message string – pure string work |
| `sendNotification(Customer c, String message)` | Handles all output (console + email) – side effects isolated here |

The top-level `processCustomer(Customer c)` then simply *orchestrates* these six steps in order, returning the computed total. This is **functional cohesion**: every routine does exactly one function, and its name describes that function completely.

---

## 2. What parameter-passing issues did you encounter?

The original signature had **eight parameters** (`n, a, d, t, e, g, orders, x`), most with one-letter names that gave no hint of their purpose. This is a classic *long parameter list* smell and makes call-sites error-prone.

More critically, line 13 of the original code reads:

```java
d = total;   // tries to update d?
```

Java passes primitive `double` arguments **by value**, so this assignment only modifies the local copy of `d` inside `processCustomer`. The caller's variable is **never updated**. The comment in the original code ("tries to update d?") confirms the author was already uncertain whether this worked.

**How I resolved it:**

1. I wrapped all parameters into a `Customer` class/struct. This immediately cuts the parameter count from 8 to 1 and gives every field a readable name (`balance`, `customerType`, etc.).
2. I changed `processCustomer` to **return** the computed total (`double`). The caller explicitly writes `alice.balance = processCustomer(alice);`, making the update visible and unambiguous.

---

## 3. How would the `d` update behave differently under pass-by-value-result?

**Pass-by-value-result** (also called *copy-in/copy-out*) is a parameter-passing strategy used in some languages (e.g., Ada's `in out` mode, some Fortran implementations). It works in two phases:

1. **Copy-in:** At the call site, the actual argument's value is copied into the formal parameter, just like pass-by-value.
2. **Copy-out (result):** When the procedure *returns*, the final value of the formal parameter is written *back* to the actual argument at the call site.

Under this strategy, line 13 (`d = total;`) would behave as intended:

- `d` is updated inside the method to hold `total`.
- On return, that final value of `d` is automatically copied back to whatever variable the caller passed as the fourth argument.
- The caller would then see the updated total without needing an explicit return value or a reference/pointer.

**In contrast, in Java (pure pass-by-value):**

- `d = total;` only changes the local copy.
- The caller sees no change whatsoever.
- The line is therefore a silent bug – the code compiles and runs without error, but the intended side-effect never happens.

This distinction is important: pass-by-value-result and pass-by-reference produce the *same* observable result for scalar updates like this one, but they differ in the presence of aliasing. Pass-by-value-result is safer in concurrent or aliased contexts because the write-back happens atomically at the return point, not continuously throughout the call.
